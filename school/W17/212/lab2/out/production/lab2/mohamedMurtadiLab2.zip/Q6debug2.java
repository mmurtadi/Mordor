/**
 * Created by mmurtadi on 30/01/17.
 */
// fixed overall indetation
// capatalized class name and changed to correspond with my naming convention
public class Q6debug2 {
    public static void main(String[] args)
    {
        // redundant second naming of "double"
        double TIME, PACE;

        // added + and closed "" on each line
        System.out.println("This program calculates your p" +
                "ace given a time " +
                "and distance traveled.");
        TIME = 35.5;
        PACE = TIME / distance;
        System.out.println("Your pace is " + PACE + " miles per hour.");
    }
    // made private
    private static final double distance = 6.21;
}

